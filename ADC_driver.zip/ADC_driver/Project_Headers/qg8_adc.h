/*
 * qg8_adc.h
 *   Simple ADC driver for the QG8
 *  Created on: Sep 22, 2015
 *      Author: Jaime Hueso
 */
#include <mc9s08qg8.h>

#ifndef QG8_ADC_H_
#define QG8_ADC_H_

#define CH0PTA0	 0x00
#define CH1PTA1	 0x01
#define CH2PTA2  0x02
#define CH3PTA3	 0x03
#define CH4PTB0	 0x04
#define CH5PTB1  0x05
#define CH6PTB2	 0x06
#define CH7PTB3	 0x07

extern unsigned int buffer;

void init_adc(unsigned char CANAL);
int lee_adc(unsigned char CANAL);
unsigned char hex2dec(unsigned char hexa);
void adc_irq(void);


#endif /* QG8_ADC_H_ */
