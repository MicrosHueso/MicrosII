#include <hidef.h> /* for EnableInterrupts macro */
#include "derivative.h" /* include peripheral declarations */
#include "qg8_adc.h"


unsigned int resultado;

void main(void) {
	SOPT1_COPE=0;
	init_adc(CH0PTA0);
	PTBDD_PTBDD7=1;
	PTBD_PTBD7=0;
  EnableInterrupts;
  for(;;) {
    resultado=lee_adc(CH0PTA0);
	PTBD_PTBD7=~PTBD_PTBD7;

  } /* loop forever */
  /* please make sure that you never leave main */
}

