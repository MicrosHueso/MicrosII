#include "qg8_adc.h"

void init_adc(unsigned char CANAL)
{
ADCSC1 =0x20 | CANAL;  // AD0/PTA0 COCO=0 ADCO=Continuo
ADCSC2 =0x00;  // ADTRG=SOFTWARE TRIGGER  ACFE=SIN COMPARADOR ADCFBT=0
ADCCFG =0x08;  // ADLPC=0 High Speed  ; ADIV=00  ; ADLSMP=SHORT TIME ; MODE=10 bits ; ADICLK=BUS_CLK
APCTL1 =0x01;  // ADPC0=PTA0 como Canal de ADC0
}


int lee_adc(unsigned char CANAL)
{
ADCSC1=0x20 | CANAL; // Trigger
while(!ADCSC1_COCO);
return ADCR;
}

unsigned char hex2dec(unsigned char hexa)
{
unsigned char resultado;
resultado=hexa/0x0a;
resultado=resultado|hexa%0x0a;
return resultado;
}

interrupt 19 void adc_irq(void)
{
buffer=ADCR;	
}
